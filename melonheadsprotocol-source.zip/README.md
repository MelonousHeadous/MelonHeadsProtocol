Development moved to https://gitlab.com/blacknet-ninja

https://melonheadsprotocol.org/ aims to continue on MelonHeadsProtocol chain.
